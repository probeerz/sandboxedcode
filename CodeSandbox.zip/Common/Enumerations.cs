﻿namespace CodeSandbox.Common
{
    public enum SandboxState
    {
        UnknownFailure,
        EnvironmentFailure,
        ConfigurationFailure,
        DataValidationFailure,
        DataSourceFailure,
        ApplicationFailure,
        Failure,
        Warning,
        SuceededWithWarning,
        Succeded,
        Information
    }
}
