﻿using System.Configuration;

namespace CodeSandbox.Configuration
{
    public class MapElement:ConfigurationElement
    {
        [ConfigurationProperty("destinationField", IsRequired = true, IsKey = true)]
        public string DestinationField { get { return (string)this["destinationField"]; } }

        [ConfigurationProperty("setExpression", IsRequired = true)]
        public string SetExpression { get { return (string)this["setExpression"]; } }
    }
}
