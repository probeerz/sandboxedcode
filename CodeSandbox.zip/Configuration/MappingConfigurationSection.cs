﻿using System.Configuration;

namespace CodeSandbox.Configuration
{
    public class MappingConfigurationSection:ConfigurationSection
    {
        [ConfigurationProperty("", IsDefaultCollection = true)]
        public MappingCollection Mappings
        {
            get
            {
                MappingCollection mappingCollection = (MappingCollection)base[""];
                return mappingCollection;
            }
        }
    }
}
