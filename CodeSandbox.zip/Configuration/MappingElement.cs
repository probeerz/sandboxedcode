﻿using System.Configuration;

namespace CodeSandbox.Configuration
{
    public class MappingElement:ConfigurationElement
    {
        [ConfigurationProperty("source", IsDefaultCollection = false)]
        public string Source 
        {
            get { return (string) this["source"]; }
            set { this["source"] = value; } 
        }

        [ConfigurationProperty("destination", IsDefaultCollection = false)]
        public string Destination
        {
            get { return (string) this["destination"]; }
            set { this["destination"] = value; }
        }
        [ConfigurationProperty("maps", IsDefaultCollection = false)]
        public MapCollection Maps { get { return (MapCollection) base["maps"]; } }
    }
}
