﻿using System.Configuration;

namespace CodeSandbox.Configuration
{
    public class SetExpression:ConfigurationElement
    {
    }
}
