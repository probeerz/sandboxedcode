﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CodeSandbox;
using CodeSandbox.Common;
using CodeSandbox.Models;

namespace SandboxedConsole
{
    class Program
    {
        public enum TestEnum
        {
            One,
            Two,
            Three,
            Four,
            Five
        };
        static void Main(string[] args)
        {
            Sandbox.Cache.Set("test", new ArithmeticException(), new TimeSpan(0, 0, 1, 0));
            Console.Read();
        }
    }
}
