﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeSandbox.Controllers.StorageManagement.Anotations;

namespace SandboxedConsole
{
    public class ScreenRegion
    {
        [Indexed]
        public string Name { get; set; }
        public DockStyle Dock { get; set; }
        public string BackColor { get; set; }
        public string ForeColor { get; set; }
        [Foreign]
        public IEnumerable<ScreenRegion> Elements { get; set; } 
    }
}
