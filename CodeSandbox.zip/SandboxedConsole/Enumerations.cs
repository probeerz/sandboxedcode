﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SandboxedConsole
{
    public enum DockStyle { None,Top, Left, Right, Bottom }
}
