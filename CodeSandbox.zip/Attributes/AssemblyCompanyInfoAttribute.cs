﻿using System;

namespace CodeSandbox.Attributes
{
    [AttributeUsage(AttributeTargets.Assembly)]
    public class AssemblyCompanyInfoAttribute : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public string CompanyName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string DivisionName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyName"></param>
        /// <param name="divisionName"></param>
        public AssemblyCompanyInfoAttribute(string companyName, string divisionName)
        {
            CompanyName = companyName;
            DivisionName = divisionName;
        }
    }
}
