﻿using System;

namespace CodeSandbox.Core
{
    public sealed class ParseException : Exception
    {
        private readonly int _position;

        public int Position
        {
            get
            {
                return _position;
            }
        }

        public ParseException(string message, int position)
            : base(message)
        {
            this._position = position;
        }

        public override string ToString()
        {
            return string.Format("{0} (at index {1})", Message, _position);
        }
    }
}
