﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using CodeSandbox.Controllers.StorageManagement.Blueprint;

namespace CodeSandbox.Controllers.StorageManagement
{
    internal class StoreElement:IStorageElement
    {
        private StoreElement()
        { }
        #region Interface Members
        public string Id { get; }
        public string Name { get; set; }
        public string Document { get; set; }
        public object Value { get; set; }
        public IStorageElement Parent { get; set; }
        public IEnumerable<IStorageElement> Dependents { get; set; }
        public IStorageElement AddDependednts(object data)
        {
            return null;
        }
        #endregion
        #region Factory

        public static void Create(object data)
        {
            
        }
        #endregion
    }
}
