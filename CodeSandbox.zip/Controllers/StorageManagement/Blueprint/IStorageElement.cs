﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeSandbox.Controllers.StorageManagement.Blueprint
{
    public interface IStorageElement
    {
        string Id { get; }
        IStorageElement AddDependednts(object data);
    }
}
