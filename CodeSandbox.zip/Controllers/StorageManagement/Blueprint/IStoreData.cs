﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeSandbox.Controllers.StorageManagement
{
    public interface IStoreData
    {
        TOfType Get<TOfType>();
        IStoreChangeLog RecentChangeLog { get; set; }
        IEnumerable<IStoreChangeLog> ChangeLogs { get; set; }
    }
}
