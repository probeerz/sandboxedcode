﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeSandbox.Contracts;

namespace CodeSandbox.Controllers
{
    public class EmailComposer:IEmailComposer
    {
        public IEmailProvider Smtp(string server)
        {
            return new SmtpProvider(server);
        }
    }

    public class SmtpProvider : IEmailProvider
    {
        private readonly string _serverName;

        public SmtpProvider(string serverName)
        {
            _serverName = serverName;
        }

        internal string ServerName { get; set; }
    }
}
