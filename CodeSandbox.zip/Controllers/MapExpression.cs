﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeSandbox.Controllers
{
    public class MapExpression<TSource, TDestination>
    {
        private MapExpression() { }
        private readonly List<Action<TSource, TDestination>> _mapList;

        internal MapExpression(List<Action<TSource, TDestination>> mapList):this()
        {
            _mapList = mapList;
        }
        public MapExpression<TSource, TDestination> AndAlsoMapAs(Action<TSource, TDestination> mapping)
        {
            _mapList.Add(mapping);
            return this;
        }

        public List<Action<TSource, TDestination>> Mappings { get { return _mapList; } }
    }
}
