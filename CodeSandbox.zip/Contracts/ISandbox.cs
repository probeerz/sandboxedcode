﻿using System;
using System.Xml.Linq;
using CodeSandbox.Controllers.StorageManagement.Blueprint;

namespace CodeSandbox.Contracts
{
    public interface ISandbox:ILogger, IExecutor,IValidator, IHelper, IDisposable, ILogData
    {
        /// <summary>
        /// 
        /// </summary>
        IValidator Ensure { get; }


        /// <summary>
        /// 
        /// </summary>
        IHelper Help { get; }

        /// <summary>
        /// 
        /// </summary>
        IExecutor Kick { get; }

        /// <summary>
        /// 
        /// </summary>
        IDependencyLibrary Library { get; }

        IMapper Mapper { get; }
        IStorageElement Store { get; }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        XElement AsXml();

        bool BlockExceptions { get; set; }
        Func<Exception, object> OnErrorReturn { get; set; }
    }
}
