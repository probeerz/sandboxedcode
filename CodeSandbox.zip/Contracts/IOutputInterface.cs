﻿namespace CodeSandbox.Contracts
{
    public interface IOutputInterface
    {
        void SendStatement(string message, params object[] args);
        void SendSuccess(string message, params object[] args);
        void SendWarning(string message, params object[] args);
        void SendFailure(string message, params object[] args);
    }
}
