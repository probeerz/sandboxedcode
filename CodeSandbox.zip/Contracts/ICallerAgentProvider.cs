﻿namespace CodeSandbox.Contracts
{
    public interface ICallerAgentProvider
    {
        IOutputInterface Output { get; }
    }
}
