﻿namespace CodeSandbox.Contracts
{
    public interface IHelper
    {
        TContent UnBox<TContent>(object box);
    }
}
