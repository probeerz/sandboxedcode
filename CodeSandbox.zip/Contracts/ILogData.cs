﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using CodeSandbox.Common;
using CodeSandbox.Models;

namespace CodeSandbox.Contracts
{
    public interface ILogData
    {
        /// <summary>
        /// The unique identifier of the sandbox.
        /// </summary>
        Guid ContextId { get; set; }

        /// <summary>
        /// Represents if the sandbox is still active and code is executing.
        /// </summary>
        bool IsOpen { get; set; }

        /// <summary>
        /// Company name which owns the code block.
        /// </summary>
        string Company { get; set; }

        /// <summary>
        /// Division name which owns the code block.
        /// </summary>
        string Division { get; set; }

        /// <summary>
        /// Machine name which ran the code block
        /// </summary>
        string MachineName { get; set; }

        /// <summary>
        /// The application which is executing the code block
        /// </summary>
        string Application { get; set; }

        /// <summary>
        /// The host assembly of the code block.
        /// </summary>
        string ComponentTitle { get; set; }

        /// <summary>
        /// The code file name of the assembly.
        /// </summary>
        string ComponentFile { get; set; }

        /// <summary>
        /// The containing code file of the executing code block
        /// </summary>
        string CallerFile { get; set; }

        /// <summary>
        /// The owning method name of the executing code block
        /// </summary>
        string CallerName { get; set; }

        /// <summary>
        /// The user who executed the code block
        /// </summary>
        string CallingUser { get; set; }

        /// <summary>
        /// The machine ip which executed this code block
        /// </summary>
        string CallerIp { get; set; }

        /// <summary>
        /// The exact position of the code block
        /// </summary>
        int CallerLine { get; set; }

        /// <summary>
        /// 
        /// </summary>
        object ReturnValue { get; set; }

        /// <summary>
        /// 
        /// </summary>
        SandboxState FinalStatus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        DateTime CallStartUtcTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        DateTime CallEndUtcTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        List<Exception> FailureExceptions { get; set; }
        /// <summary>
        /// 
        /// </summary>
        List<Exception> IgnoredExceptions { get; set; }
        /// <summary>
        /// 
        /// </summary>
        List<CallArgument> CallArguments { get; set; }
        /// <summary>
        /// 
        /// </summary>
        List<LogicalStep> RecordedSteps { get; set; }

    }
}
