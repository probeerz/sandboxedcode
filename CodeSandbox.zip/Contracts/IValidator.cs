﻿using System;
using System.Linq.Expressions;

namespace CodeSandbox.Contracts
{
    public interface IValidator
    {
        void NotNull<TContent>(Expression<Func<TContent>> dataToValidate) where TContent:class;
        void NotDefault<TContent>(Expression<Func<TContent>> dataToValidate);
        void That(Expression<Func<bool>> dataToValidate);
    }
}
