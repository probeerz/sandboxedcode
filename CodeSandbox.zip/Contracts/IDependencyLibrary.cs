﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CodeSandbox.Contracts
{
    public interface IDependencyLibrary
    {
        TToBeInjected Get<TToBeInjected>(Expression<Func<TToBeInjected, bool>> filter,
            bool alwaysCreateNew = false) where TToBeInjected : class;

        TToBeInjected Get<TToBeInjected>(bool alwaysCreateNew = false) where TToBeInjected : class;
        Type GetEnumByName(string enumName, Expression<Func<Type, bool>> filter = null);
    }
}
