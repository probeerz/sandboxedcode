﻿using System;

namespace CodeSandbox.Contracts
{
    public interface IExecutor
    {
        TReturn SafeRun<TReturn>(Func<TReturn> logic);
        TReturn RunAndIgnore<TReturn, TKnownException>(Func<TReturn> logic);
        void RunAndExpect<TReturn, TExpectedException>(Func<TReturn> logic);
    }
}
