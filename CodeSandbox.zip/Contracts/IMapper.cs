﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CodeSandbox.Contracts
{
    public interface IMapper
    {
        TDestination Map<TSource, TDestination>(TSource source, TDestination destination,
            object parentObject = null, params Expression<Func<object>>[] parameters) where TSource : class
            where TDestination : class, new();

        TDestination Map<TSource, TDestination>(TSource source, object parentObject = null,
            params Expression<Func<object>>[] parameters)
            where TSource : class
            where TDestination : class, new();
    }
}
