﻿using System;
using System.Runtime.CompilerServices;

namespace CodeSandbox.Contracts
{
    public interface ILogger
    {
        void TagAsStatement(string statement, [CallerFilePath] string callerFile = @"N/A", [CallerMemberName] string callerName = @"N/A", [CallerLineNumber] int callerLine = 0);
        void TagAsSuccededStep(string successMessage = null, [CallerFilePath] string callerFile = @"N/A", [CallerMemberName] string callerName = @"N/A", [CallerLineNumber] int callerLine = 0);
        void TagAsWarningStep(string warningMessage = null, [CallerFilePath] string callerFile = @"N/A", [CallerMemberName] string callerName = @"N/A", [CallerLineNumber] int callerLine = 0);
        void TagAsFailedStep(string failureMessage = null,[CallerFilePath] string callerFile = @"N/A", [CallerMemberName] string callerName = @"N/A", [CallerLineNumber] int callerLine = 0);
        void LogArguments(params object[] parameters);
        void LogIgnoredException(Exception exception);
        void LogFailureException(Exception exception);
        void LogReturnValue(object returnValue);
    }
}
