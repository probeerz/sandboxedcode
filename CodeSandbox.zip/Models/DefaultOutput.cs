﻿using System.Diagnostics;
using CodeSandbox.Contracts;

namespace CodeSandbox.Models
{
    internal class DefaultOutput:IOutputInterface
    {
        public void SendStatement(string message, params object[] args)
        {
            Debug.WriteLine(string.Concat("Statement:", message), args);
        }

        public void SendWarning(string message, params object[] args)
        {
            Debug.WriteLine(string.Concat("Warning:", message), args);
        }

        public void SendFailure(string message, params object[] args)
        {
            Debug.WriteLine(string.Concat("Failure:", message), args);
        }


        public void SendSuccess(string message, params object[] args)
        {
            Debug.WriteLine(string.Concat("Success:", message), args);
        }
    }
}
