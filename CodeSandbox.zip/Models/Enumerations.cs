﻿namespace CodeSandbox.Models
{
    /// <summary>
    /// 
    /// </summary>
    public enum LogType
    {
        /// <summary>
        /// 
        /// </summary>
        UnknownFailure,
        /// <summary>
        /// 
        /// </summary>
        EnvironmentFailure,
        /// <summary>
        /// 
        /// </summary>
        ConfigurationFailure,
        /// <summary>
        /// 
        /// </summary>
        DataValidationFailure,
        /// <summary>
        /// 
        /// </summary>
        DataSourceFailure,
        /// <summary>
        /// 
        /// </summary>
        ApplicationFailure,
        /// <summary>
        /// 
        /// </summary>
        Failure,
        /// <summary>
        /// 
        /// </summary>
        Warning,
        /// <summary>
        /// 
        /// </summary>
        SuceededWithWarning,
        /// <summary>
        /// 
        /// </summary>
        Succeded,
        /// <summary>
        /// 
        /// </summary>
        Information
    }

    public enum LogMode
    {
        None
       ,BasicCallInfo
       ,OnlyFailures 
       ,OnlyWarnings 
       ,OnlyInformation
       ,FailuresAndWarnings
       ,GoVerbose
    }

    public enum LogDestination
    {
        EventLog,
        LocalFile,
        UserFunction,
        FailoverSequence
    }
}
