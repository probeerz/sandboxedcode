﻿using System;
using System.Xml.Serialization;

namespace CodeSandbox.Models
{
    public class LogicalStep
    {
        [XmlAttribute]
        public int StepNumber { get; set; }
        [XmlAttribute]
        public DateTime ExecutedAt { get; set; }
        [XmlAttribute]
        public LogType StepType { get; set; }
        [XmlAttribute]
        public string CallerFile { get; set; }
        [XmlAttribute]
        public string CallerName { get; set; }
        [XmlAttribute]
        public int CallerLine { get; set; }
        public string Message { get; set; }
    }
}
