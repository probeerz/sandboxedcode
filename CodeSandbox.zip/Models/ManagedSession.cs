﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Timers;

namespace CodeSandbox.Models
{
    public class ManagedSession
    {
        readonly Timer _expirationTimer = new Timer();
        private readonly ConcurrentDictionary<string, CacheItem> _cache;
        static ManagedSession()
        {
            Store = new ManagedSession();
        }

        public object this[string key] => _cache[key];

        private ManagedSession()
        {
            _cache = new ConcurrentDictionary<string, CacheItem>();
            _expirationTimer.Interval = 1000;
            _expirationTimer.Elapsed += ExpirationTimer_Elapsed;
        }

        private void ExpirationTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            var expiredItems = _cache.Where(pair => pair.Value.LifeSpan.TotalSeconds > 0 && pair.Value.LifeSpan < DateTime.Now.Subtract(pair.Value.CreatedAt));
            foreach (var item in expiredItems)
            {
                CacheItem cItem;
                _cache.TryRemove(item.Key, out cItem);
            }
        }

        public bool Set(string key, object item, TimeSpan lifeSpan = default(TimeSpan))
        {
            if(string.IsNullOrWhiteSpace(key)) throw new ArgumentNullException(nameof(key));
            _cache.AddOrUpdate(key, new CacheItem
            {
                Key = key,
                Item = item,
                ItemType = item.GetType(),
                CreatedAt = DateTime.Now,
                LifeSpan = lifeSpan
            },(k, cacheItem) => _cache[k] = cacheItem );
            return true;
        }

        public TValue Get<TValue>(string key)
        {
            if (_cache.ContainsKey(key))
            {
                var cacheItem = _cache[key];
                if (typeof(TValue) == cacheItem.ItemType)
                {
                    return (TValue) Convert.ChangeType(_cache[key], typeof(TValue));
                }
                return default(TValue);
            }
            return default(TValue);
        }

        public bool Remove(string key)
        {
            CacheItem cItem;
            return _cache.TryRemove(key, out cItem);
        }

        public bool Exists(string key)
        {
            return _cache.ContainsKey(key);
        }

        public static ManagedSession Store { get; private set; }


    }
}
