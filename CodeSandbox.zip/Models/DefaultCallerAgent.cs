﻿using CodeSandbox.Contracts;

namespace CodeSandbox.Models
{
    internal class DefaultCallerAgent:ICallerAgentProvider
    {
        public IOutputInterface Output
        {
            get { return new DefaultOutput(); }
        }
    }
}
