﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeSandbox.Models
{
    public class CacheItem
    {
        public string Key { get; set; }
        internal Type ItemType { get; set; }
        public object Item { get; set; }
        internal DateTime CreatedAt { get; set; }
        internal TimeSpan LifeSpan { get; set; }
    }
}
