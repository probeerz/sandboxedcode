﻿using System.Xml.Linq;
using System.Xml.Serialization;

namespace CodeSandbox.Models
{
    public class CallArgument
    {
        [XmlAttribute]
        public string Name { get; set; }
        [XmlAttribute]
        public object Value { get; set; }
    }
}
